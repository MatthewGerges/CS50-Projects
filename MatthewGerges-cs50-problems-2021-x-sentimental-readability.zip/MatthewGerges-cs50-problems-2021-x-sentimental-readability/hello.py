# ask the user for their name and store it in a variable called name
name = input("What is your name? ")
# using a fomratted string print hello, the user's name

print(f"hello, {name}")

# Other ways to do the same thing
#print("hello, " + name)
#print("hello,", name)